
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class LoginSteps {
    
    private WebDriver driver;

    public LoginSteps() {
        this.driver = Setup.driver;
    }

    @When("^I leave the email field blank$")
    public void i_leave_the_email_field_blank() {
        driver.findElement(By.id("email")).sendKeys("");
    }

    @When("^I leave the password field blank$")
    public void i_leave_the_password_field_blank() {
        driver.findElement(By.id("password")).sendKeys("");
    }

    @When("^I click the "([^"]*)" button$")
    public void i_click_the_button(String button) {
        driver.findElement(By.xpath("//button[text()='" + button + "']")).click();
    }

    @Then("^I should see an error message "([^"]*)"$")
    public void i_should_see_an_error_message(String message) {
        String displayedMessage = driver.findElement(By.id("error")).getText();
        assert(displayedMessage.contains(message));
    }
}

    @When("^I enter "([^"]*)" in the email field$")
    public void i_enter_in_the_email_field(String email) {
        driver.findElement(By.id("email")).sendKeys(email);
    }

    @When("^I enter "([^"]*)" in the password field$")
    public void i_enter_in_the_password_field(String password) {
        driver.findElement(By.id("password")).sendKeys(password);
    }

    @When("^I do not check the "([^"]*)" box$")
    public void i_do_not_check_the_box(String box) {
        // Normally, to uncheck or skip checking a checkbox, you might find it by its label or description.
    }

    @Then("^I should see an error message "([^"]*)"$")
    public void i_should_see_an_error_message_for_terms(String message) {
        String displayedMessage = driver.findElement(By.id("error_terms")).getText();
        assert(displayedMessage.contains(message));
    }

    @When("^I check the "([^"]*)" box$")
    public void i_check_the_box(String box) {
        // Check the box by finding it by its label or description.
    }

    @When("^I do not complete the CAPTCHA$")
    public void i_do_not_complete_the_CAPTCHA() {
        // Intentionally skip the CAPTCHA step.
    }

    @Then("^I should see an error message "([^"]*)"$")
    public void i_should_see_an_error_message_for_captcha(String message) {
        String displayedMessage = driver.findElement(By.id("error_captcha")).getText();
        assert(displayedMessage.contains(message));
    }

@Given("^I am on the login page$")
public void i_am_on_the_login_page() {
    driver.get("https://www.trendyol.com/login");
}

@When("^I enter an unregistered email "([^"]*)" in the email field$")
public void i_enter_an_unregistered_email_in_the_email_field(String email) {
    driver.findElement(By.id("email")).sendKeys(email);
}

@When("^I enter a valid password "([^"]*)" in the password field$")
public void i_enter_a_valid_password_in_the_password_field(String password) {
    driver.findElement(By.id("password")).sendKeys(password);
}

@When("^I click the "([^"]*)" button$")
public void i_click_the_button(String button) {
    driver.findElement(By.xpath("//button[text()='" + button + "']")).click();
}

@Then("^I should see an error message "([^"]*)"$")
public void i_should_see_an_error_message(String message) {
    String displayedMessage = driver.findElement(By.id("error")).getText();
    assert(displayedMessage.contains(message));
}

@Given("^I am on the login page$")
public void i_am_on_the_login_page() {
    driver.get("https://www.trendyol.com/login");
}

@When("^I enter a valid email "([^"]*)" in the email field$")
public void i_enter_a_valid_email_in_the_email_field(String email) {
    driver.findElement(By.id("email")).sendKeys(email);
}

@When("^I enter a valid password "([^"]*)" in the password field$")
public void i_enter_a_valid_password_in_the_password_field(String password) {
    driver.findElement(By.id("password")).sendKeys(password);
}

@When("^I click the "([^"]*)" button$")
public void i_click_the_button(String button) {
    driver.findElement(By.xpath("//button[text()='" + button + "']")).click();
}

@Then("^I should see a welcome message "([^"]*)"$")
public void i_should_see_a_welcome_message(String message) {
    String displayedMessage = driver.findElement(By.id("welcomeMessage")).getText();
    assert(displayedMessage.contains(message));
}

@Given("^I am on the login page$")
public void i_am_on_the_login_page() {
    driver.get("https://www.trendyol.com/login");
}

@When("^I enter a valid email "([^"]*)" in the email field$")
public void i_enter_a_valid_email_in_the_email_field(String email) {
    driver.findElement(By.id("email")).sendKeys(email);
}

@When("^I enter an invalid password "([^"]*)" in the password field$")
public void i_enter_an_invalid_password_in_the_password_field(String password) {
    driver.findElement(By.id("password")).sendKeys(password);
}

@When("^I click the "([^"]*)" button$")
public void i_click_the_button(String button) {
    driver.findElement(By.xpath("//button[text()='" + button + "']")).click();
}

@Then("^I should see an error message "([^"]*)"$")
public void i_should_see_an_error_message(String message) {
    String displayedMessage = driver.findElement(By.id("error")).getText();
    assert(displayedMessage.contains(message));
}

@Given("^I am on the login page$")
public void i_am_on_the_login_page() {
    driver.get("https://www.trendyol.com/login");
}

@When("^I enter an invalid email "([^"]*)" in the email field$")
public void i_enter_an_invalid_email_in_the_email_field(String email) {
    driver.findElement(By.id("email")).sendKeys(email);
}

@When("^I enter a valid password "([^"]*)" in the password field$")
public void i_enter_a_valid_password_in_the_password_field(String password) {
    driver.findElement(By.id("password")).sendKeys(password);
}

@When("^I click the "([^"]*)" button$")
public void i_click_the_button(String button) {
    driver.findElement(By.xpath("//button[text()='" + button + "']")).click();
}

@Then("^I should see an error message "([^"]*)"$")
public void i_should_see_an_error_message(String message) {
    String displayedMessage = driver.findElement(By.id("error")).getText();
    assert(displayedMessage.contains(message));
}

@Given("^I am on the login page$")
public void i_am_on_the_login_page() {
    driver.get("https://www.trendyol.com/login");
}

@When("^I enter an invalid email "([^"]*)" in the email field$")
public void i_enter_an_invalid_email_in_the_email_field(String email) {
    driver.findElement(By.id("email")).sendKeys(email);
}

@When("^I enter an invalid password "([^"]*)" in the password field$")
public void i_enter_an_invalid_password_in_the_password_field(String password) {
    driver.findElement(By.id("password")).sendKeys(password);
}

@When("^I click the "([^"]*)" button$")
public void i_click_the_button(String button) {
    driver.findElement(By.xpath("//button[text()='" + button + "']")).click();
}

@Then("^I should see an error message "([^"]*)"$")
public void i_should_see_an_error_message(String message) {
    String displayedMessage = driver.findElement(By.id("error")).getText();
    assert(displayedMessage.contains(message));
}

@Given("^I am on the login page$")
public void i_am_on_the_login_page() {
    driver.get("https://www.trendyol.com/login");
}

@When("^I leave the email field blank$")
public void i_leave_the_email_field_blank() {
    driver.findElement(By.id("email")).clear();
}

@When("^I leave the password field blank$")
public void i_leave_the_password_field_blank() {
    driver.findElement(By.id("password")).clear();
}

@When("^I click the "([^"]*)" button$")
public void i_click_the_button(String button) {
    driver.findElement(By.xpath("//button[text()='" + button + "']")).click();
}

@Then("^I should see an error message "([^"]*)"$")
public void i_should_see_an_error_message(String message) {
    String displayedMessage = driver.findElement(By.id("error")).getText();
    assert(displayedMessage.contains(message));
}

@Given("^I am on the login page$")
public void i_am_on_the_login_page() {
    driver.get("https://www.trendyol.com/login");
}

@When("^I leave the email field blank$")
public void i_leave_the_email_field_blank() {
    driver.findElement(By.id("email")).clear();
}

@When("^I enter a valid password "([^"]*)" in the password field$")
public void i_enter_a_valid_password_in_the_password_field(String password) {
    driver.findElement(By.id("password")).sendKeys(password);
}

@When("^I click the "([^"]*)" button$")
public void i_click_the_button(String button) {
    driver.findElement(By.xpath("//button[text()='" + button + "']")).click();
}

@Then("^I should see an error message "([^"]*)"$")
public void i_should_see_an_error_message(String message) {
    String displayedMessage = driver.findElement(By.id("error")).getText();
    assert(displayedMessage.contains(message));
}

@Given("^I am on the login page$")
public void i_am_on_the_login_page() {
    driver.get("https://www.trendyol.com/login");
}

@When("^I enter a valid email "([^"]*)" in the email field$")
public void i_enter_a_valid_email_in_the_email_field(String email) {
    driver.findElement(By.id("email")).sendKeys(email);
}

@When("^I leave the password field blank$")
public void i_leave_the_password_field_blank() {
    driver.findElement(By.id("password")).clear();
}

@When("^I click the "([^"]*)" button$")
public void i_click_the_button(String button) {
    driver.findElement(By.xpath("//button[text()='" + button + "']")).click();
}

@Then("^I should see an error message "([^"]*)"$")
public void i_should_see_an_error_message(String message) {
    String displayedMessage = driver.findElement(By.id("error")).getText();
    assert(displayedMessage.contains(message));
}

@Given("^I am on the login page$")
public void i_am_on_the_login_page() {
    driver.get("https://www.trendyol.com/login");
}

@When("^I enter a valid email "([^"]*)" in the email field$")
public void i_enter_a_valid_email_in_the_email_field(String email) {
    driver.findElement(By.id("email")).sendKeys(email);
}

@When("^I enter a valid password "([^"]*)" in the password field$")
public void i_enter_a_valid_password_in_the_password_field(String password) {
    driver.findElement(By.id("password")).sendKeys(password);
}

@When("^I check the "([^"]*)" checkbox$")
public void i_check_the_checkbox(String checkbox) {
    driver.findElement(By.id(checkbox)).click();
}

@When("^I click the "([^"]*)" button$")
public void i_click_the_button(String button) {
    driver.findElement(By.xpath("//button[text()='" + button + "']")).click();
}

@Then("^I should be logged in$")
public void i_should_be_logged_in() {
    // This step would normally verify elements visible only when logged in.
}

@Then("^my login should persist even after closing and reopening the browser$")
public void my_login_should_persist() {
    // This step would simulate closing and reopening the browser, then check if the session persists.
}

@Given("^I am on the login page$")
public void i_am_on_the_login_page() {
    driver.get("https://www.trendyol.com/login");
}

@When("^I enter a valid email "([^"]*)" in the email field$")
public void i_enter_a_valid_email_in_the_email_field(String email) {
    driver.findElement(By.id("email")).sendKeys(email);
}

@When("^I enter a password "([^"]*)" in the password field$")
public void i_enter_a_password_in_the_password_field(String password) {
    driver.findElement(By.id("password")).sendKeys(password);
}

@When("^I click the "([^"]*)" button$")
public void i_click_the_button(String button) {
    driver.findElement(By.id(button)).click();
}

@Then("^the password should be visible$")
public void the_password_should_be_visible() {
    String type = driver.findElement(By.id("password")).getAttribute("type");
    assert(type.equals("text")); // Check if the password input type is text, which means visible
}

@Then("^the password should be hidden$")
public void the_password_should_be_hidden() {
    String type = driver.findElement(By.id("password")).getAttribute("type");
    assert(type.equals("password")); // Check if the password input type is password, which means hidden
}

@Given("^I am on the login page on "([^"]*)"$")
public void i_am_on_the_login_page_on_browser(String browser) {
    if(browser.equals("Chrome")) {
        System.setProperty("webdriver.chrome.driver", "path_to_chromedriver");
        driver = new ChromeDriver();
    } else if(browser.equals("Firefox")) {
        System.setProperty("webdriver.gecko.driver", "path_to_geckodriver");
        driver = new FirefoxDriver();
    } else if(browser.equals("Safari")) {
        driver = new SafariDriver();
    } else if(browser.equals("Edge")) {
        System.setProperty("webdriver.edge.driver", "path_to_edgedriver");
        driver = new EdgeDriver();
    }
    driver.get("https://www.trendyol.com/login");
}

@When("^I click the "([^"]*)" button$")
public void i_click_the_button(String button) {
    driver.findElement(By.xpath("//button[text()='" + button + "']")).click();
}

@Then("^I should be logged in$")
public void i_should_be_logged_in() {
    // This step would normally verify elements visible only when logged in.
}
